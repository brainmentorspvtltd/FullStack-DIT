import React from 'react'
import { Questions } from '../../../modules/questions/pages/Questions'
import Header from '../components/Header'
import Section from '../components/Section'

const Home = () => {
  return (
    <div>
        <Header/>
        <Section/>
        <Questions/>
    </div>
  )
}

export default Home