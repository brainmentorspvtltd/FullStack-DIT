import React from 'react'

export const Question = (props) => {
  return (
   <tr>
        <td>{props.ques.id}</td>
        <td>{props.ques.name}</td>
        <td>{props.ques.tag}</td>
        <td>{props.ques.companies}</td>
        <td>{props.ques.level}</td>
   </tr>
  )
}
