import { Question } from "../../modules/questions/models/question";

// BackEnd Api Calls
export const API_CLIENT = {
    get(){
        // Hard Coding 
        const questions = [];
        questions.push(new Question(1001, "Two Sum", "Array", "Amazon","Easy"));
        questions.push(new Question(1002, "Fibo", "Loop", "Oracle","Easy"));
        questions.push(new Question(1003, "Three Sum", "Array", "Amazon","Medium"));
        questions.push(new Question(1004, "N Queen Problem", "BackTracking", "Intel","Hard"));
        return questions;
    }
}