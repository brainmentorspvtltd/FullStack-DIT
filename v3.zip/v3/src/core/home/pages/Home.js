import React from 'react'
import { Questions } from '../../../modules/questions/pages/Questions'
import Header from '../components/Header'
import Section from '../components/Section'
import {Route, Routes} from 'react-router-dom';
import { ProblemStatement } from '../../../modules/ide/pages/ProblemStatement';
import { ErrorComponent } from '../../../shared/components/ErrorComponent';

const Home = () => {
  return (
    <div>
      
      <Routes>
        
      <Route path = "/" element = {<Header/>} /> 
          {/* <Route path = "/section" element = {<Section/>} />  */}
          <Route path = "/questions" element = {<Questions/>} />
          <Route path = "/problemstatement/:qid" element = {<ProblemStatement/>}  />
          <Route path="*" element = {<ErrorComponent/>} />
        </Routes>
        
        
    </div>
  )
}

export default Home