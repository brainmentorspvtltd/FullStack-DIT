
import './App.css';
import Home from './core/home/pages/Home';
import { ProblemStatement } from './modules/ide/pages/ProblemStatement';

function App() {
  return (
    <div >
      <Home/>
    </div>
  );
}

export default App;
