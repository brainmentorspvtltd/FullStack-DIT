
import './App.css';
import Home from './core/home/pages/Home';

function App() {
  return (
    <div className = 'container'>
    <Home/>
    </div>
  );
}

export default App;
