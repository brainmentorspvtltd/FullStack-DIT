import { CONFIG } from "./config.js";
import { Sprite } from "./sprite.js";

export class Player extends Sprite{
    constructor(){
        super(10, 0, 100,100,'./assets/images/player.gif'); // Calling a Parent class Constructor
        this.y = CONFIG.FLOOR - this.h;
        this.speed = 10;
        // this.x = 10;
        // this.h = 100;
        // this.w = 100;
        // this.y = CONFIG.FLOOR - this.h;
        //this.speed = 2;
        // this.image = new Image();
        // this.image.src = './assets/images/player.gif';
    }
    outOfScreen(){
        if(this.x>CONFIG.BOARD_WIDTH){
            return true;
        }
        return false;
    }
    move(){
        this.x = this.x + this.speed;
    }
    draw(ctx){
        
            ctx.drawImage(this.image, this.x, this.y, this.w, this.h);
        
    }
}