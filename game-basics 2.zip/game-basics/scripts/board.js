import { CONFIG } from "./config.js";
import { Enemy } from "./enemy.js";
import { Player } from "./player.js";

export class Board{
    constructor(ctx){
        this.ctx  = ctx;
        this.image = new Image();
        this.image.src = './assets/images/bg.jpg';
       
        this.player = new Player();
        this.enemies = this.loadEnemies();
        //this.enemy = new Enemy();
        this.interval = undefined;
        this.gameLoop();
        this.gameMessage = "";
    }

    gameOver(){
            this.gameMessage = "GAME WIN";
    }

    drawMessage(){
        if(this.gameMessage.length>0){
        this.ctx.font = '30px serif';
        this.ctx.fillText(this.gameMessage, CONFIG.BOARD_WIDTH/2, CONFIG.BOARD_HEIGHT/2);
        }
    }

    keyCapture(event){
            console.log('Key Event ', event.keyCode);
            if(event.keyCode == CONFIG.RIGHT_ARROW){
                this.player.move();
                if(this.player.outOfScreen()){
                    this.gameOver();
                }
            }
    }

    loadEnemies(){
        const GAP = 250;
        let currentX = 50;
        let speed = 5;
        const enemies = [];
        let lastX = 0;
        for(let i = 0; i<CONFIG.MAX_ENEMY; i++){
            let enemy = new Enemy();
            enemy.x = lastX + currentX + GAP;
            lastX = enemy.x;
            enemy.speed = speed;
            speed = speed + 3;
            enemies.push(enemy);
            
        }
        return enemies;
    }

    gameLoop(){
        this.interval = setInterval(()=>{
            this.draw();
            //console.log('Game Loop');
        },50);
    }

    // Player and enemy both will be draw on Board.



    draw(){
       
            //console.log('What is this ',this);
            this.ctx.clearRect(0,0,CONFIG.BOARD_WIDTH, CONFIG.BOARD_HEIGHT);
            this.ctx.drawImage(this.image, 0, 0);
            this.player.draw(this.ctx);
            this.drawEnemies();
            this.drawMessage();
            
            //this.enemy.draw(this.ctx);
        
        
    }

    drawEnemies(){
        for(let enemy of this.enemies){
            enemy.draw(this.ctx);
        }
    }
}
