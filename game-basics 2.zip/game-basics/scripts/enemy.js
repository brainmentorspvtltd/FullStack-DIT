import { CONFIG } from "./config.js";
import { Sprite } from "./sprite.js";

export class Enemy extends Sprite{
    constructor(){
        super(200, 50, 100,100,'./assets/images/spider.png');
        this.speed = 5;
    }
    move(){
        this.y = this.y + this.speed;
        this.outOfScreen();
    }

    outOfScreen(){
        if(this.y>CONFIG.BOARD_HEIGHT){
            this.y = 0;
        }
    }

    draw(ctx){
       
            ctx.drawImage(this.image, this.x, this.y, this.w, this.h);
        
        this.move();
    }

}