import React, { useRef } from 'react'
import Editor from '@monaco-editor/react';
export const CodeEditor = () => {
  const editorRef = useRef({});
  const options = {
    'fontSize':30, selectOnLineNumbers:true, cursorStyle:'line',
    colorDecorators:true, scrollbar:{
      useShadows:false, verticalHasArrows : true, horizontalHasArrows: true, vertical : 'visible',
      horizontal: 'visible'
    }
  };

  const handleEditorDidMount = (editor, monaco)=>{
      editorRef.current = editor;
      console.log('handleEditorDidMount Call ');
  }

  const compileAndRun = ()=>{
    console.log('Editor Ref ', editorRef.current);
      const code = editorRef.current.getValue();
      console.log('Code is ', code);
  }
  return (
    <div className='col'>
        <Editor theme='vs-dark' height="90%" 
        width="100%" defaultLanguage='java'
        onMount={handleEditorDidMount}
         defaultValue='class Solution {}'
         options={options}
         />
         <br/>
    <button className = 'btn btn-primary' onClick={compileAndRun}>Compile and Run</button>
    </div>
  )
}
