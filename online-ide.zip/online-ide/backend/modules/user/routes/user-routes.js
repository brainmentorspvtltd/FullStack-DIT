const express = require('express');
const routes = express.Router();
const {OAUTH} = require('../../../shared/config/constants').ROUTES.USER;
const {oAuth} = require('../controllers/user-controller');
routes.post(OAUTH,oAuth);
module.exports = routes;