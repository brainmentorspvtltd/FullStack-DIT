// const os = require('os');
const os = require('os');
const fs = require('fs');
console.log(os.cpus().length);
// console.log(os);
console.log('DIr ', __dirname);
console.log('File Name ', __filename);
fs.readFile(__filename, (err, buffer)=>{
    if(err){
        console.log('Error While File Read ', err);
    }
    else{
        console.log('Content is ', buffer.toString());
    }
});
console.log('Bye Bye Code...');
