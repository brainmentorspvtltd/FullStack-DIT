//const calcObject = require('./calc');
import {calc} from './calc.js';
import chalk from 'chalk';
console.log(chalk.red.bold(calc.add(10,20)));
console.log(chalk.yellow.italic(calc.subtract(100,200)));