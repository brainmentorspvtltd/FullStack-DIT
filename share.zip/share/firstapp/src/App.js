import React from 'react';
// Root Component
// Component is a function
// JSX
// export function App(){
//   return (<h1>Hello React JS....</h1>)
// }
// Arrow Function (ES6)
// a) Small 
// b) Pure function
export const App = ()=>{
  return React.createElement('div', null,  React.createElement('h1',null,'Hello React '),  React.createElement('h2',null,'Hi React '))
  //return React.createElement('h1',null,'Hello React ') 
// return (
// <div>
// <h1>Hello React JS- Arrow Function</h1>
// <h2>Hello React JS- Arrow Function</h2>
// </div>
// )
}