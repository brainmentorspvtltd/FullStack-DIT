import { Board } from "./board.js";
import { CONFIG } from "./config.js";

window.addEventListener("load", bindEvents);

function bindEvents(){
    const canvas = document.querySelector('#board');
    canvas.width = CONFIG.BOARD_WIDTH;
    canvas.height = CONFIG.BOARD_HEIGHT;
    const context = canvas.getContext('2d');
    let board = new Board(context); 
}











// /*
// Just Try Canvas
// */ 
// const canvas = document.querySelector('#board');
// canvas.width = 1200;
// canvas.height = 700;
// const context = canvas.getContext('2d');

// // context.fillStyle = 'green';
// // context.fillRect(10,10,50,50);
// // context.strokeRect(100,100,50,50);

// // Triangle
// // context.lineWidth=10;
// // context.fillStyle='red';
// // context.beginPath();
// // context.moveTo(10,20);
// // context.lineTo(10,100);
// // context.lineTo(200,100);
// // context.fill();
// // context.closePath();

// // Draw Text
// // context.font= '12px times';
// // context.strokeText('Game Over',10,50);

// // Draw Image
// const image = new Image();
// image.src = './assets/images/bg.jpg';
// image.onload = function(){
//     context.drawImage(image, 0, 0);
// }

