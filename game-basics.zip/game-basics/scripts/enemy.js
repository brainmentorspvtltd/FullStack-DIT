import { Sprite } from "./sprite.js";

export class Enemy extends Sprite{
    constructor(){
        super(200, 50, 100,100,'./assets/images/spider.png');
        this.speed = 5;
    }
    move(){
        this.y = this.y + this.speed;
    }
    draw(ctx){
       
            ctx.drawImage(this.image, this.x, this.y, this.w, this.h);
        
        this.move();
    }

}