export class Board{
    constructor(ctx){
        this.ctx  = ctx;
        this.image = new Image();
        this.image.src = './assets/images/bg.jpg';
        this.drawBackGround();
        
    }
    drawBackGround(){
        this.image.onload = ()=>{
            console.log('What is this ',this);
            this.ctx.drawImage(this.image, 0, 0);
        }
        
    }
}
