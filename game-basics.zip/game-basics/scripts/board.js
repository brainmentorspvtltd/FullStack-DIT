import { Enemy } from "./enemy.js";
import { Player } from "./player.js";

export class Board{
    constructor(ctx){
        this.ctx  = ctx;
        this.image = new Image();
        this.image.src = './assets/images/bg.jpg';
       
        this.player = new Player();
        this.enemy = new Enemy();
        this.interval = undefined;
        this.gameLoop();
    }

    gameLoop(){
        this.interval = setInterval(()=>{
            this.drawBackGround();
            console.log('Game Loop');
        },50);
    }

    // Player and enemy both will be draw on Board.



    drawBackGround(){
       
            console.log('What is this ',this);
            this.ctx.drawImage(this.image, 0, 0);
            this.player.draw(this.ctx);
            this.enemy.draw(this.ctx);
        
        
    }
}
