const express = require('express');
const app = express();
// console.log('Express ', typeof express);
// console.log('App ', typeof app);
app.listen(1234, (err)=>{
    if(err){
        console.log(' Server Crash ', err);
    }
    else{
        console.log("Server Up and Running...");
    }
})