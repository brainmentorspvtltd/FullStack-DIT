export const CONFIG = {
    BOARD_WIDTH : 1200,
    BOARD_HEIGHT : 700,
    FLOOR : 700 - 70,
    MAX_ENEMY : 3,
    RIGHT_ARROW : 39,
    LEFT_ARROW: 37,
    SPACE:32,
    GRAVITY:1,
    ENTER_KEY : 13
    

}