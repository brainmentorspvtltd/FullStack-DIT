const express = require('express');
const app = express();
require('dotenv').config();
const userRoutes = require('./modules/user/routes/user-routes');
const {HOME} = require('./shared/config/constants').ROUTES;
const messageReader = require('./shared/i18n/message-reader');
app.use(express.json());
app.use(HOME,userRoutes);
const serverInfo = app.listen(process.env.PORT || 1234, (err)=>{
    if(err){
        console.log(messageReader('server.crash.message'), err);
    }
    else{
        console.log(messageReader('server.success.message') , serverInfo.address().port);
    }
})