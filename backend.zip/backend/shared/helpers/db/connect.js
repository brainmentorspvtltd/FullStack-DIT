const mongoose = require('mongoose');
const URL = 'mongodb+srv://amit:amit123456@online-ide-cluster.pantpag.mongodb.net/onlineidedb?retryWrites=true&w=majority';
mongoose.connect(URL,(err)=>{
    if(err){
        console.log('Error in DB Connection ', err);
    }
    else{
        console.log('DB Connection Establish');
    }
});