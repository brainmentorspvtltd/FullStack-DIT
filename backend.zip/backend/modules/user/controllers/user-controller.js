const messageReader = require('../../../shared/i18n/message-reader');

// Controller is For Request and Response Handling
const {SUCCESS} = require('../../../shared/config/constants').HTTP_STATUS_CODES;
module.exports = {
    oAuth(request, response){
            const body = request.body;
            console.log('Req Body ', body);
            response.status(SUCCESS).json({'message':messageReader('welcome.message')+body.name});
        }
    }
