import { useState } from "react";

export const Count = ()=>{
    const [count, setCount] = useState(0); // count init value 0
    console.log('Count Call....');
    //let count = 0;
    const plus = ()=>{

        // Immutable Way
        setCount(count+1); // Call Count fn again with new state
        // Mutable Way
        //count = count + 1; // Count Increment , Render It...
        //console.log('Plus Call...', count);
    }
    return (<div>
        <h2>Count is {count}</h2>
        <button onClick={plus}>Click Me</button>
    </div>)
}