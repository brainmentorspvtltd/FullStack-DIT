 const Own = (props)=>{
    console.log('Rec Args ', props, typeof props);
    return (<h1>A is {props.a} and B is {props.b} This is My Component</h1>)
}
// export const MAX = 100;
// export const add = ()=>{
//     return 1000;
// }
export default Own;