import { App } from "./App";
import ReactDOM from 'react-dom';
// index.js - Bridge file b/w index.html and app component (root)
const rootDiv = document.querySelector('#root');
ReactDOM.render(<App/>, rootDiv); // <App/> JSX Style (Calling a Function)