'use strict'
const messageReader = require('../../../shared/i18n/message-reader');
const userOperations = require('../db/repository/user-operations');

// Controller is For Request and Response Handling
const {SUCCESS,SERVER_ERROR} = require('../../../shared/config/constants').HTTP_STATUS_CODES;
module.exports = {
    async oAuth(request, response){
            const userData = request.body;
            try{
            //const doc = await userOperations.add(userData);
            const doc = await userOperations.read(userData);
            response.status(SUCCESS).json({'message':messageReader('welcome.message'), userinfo: doc});
            }
            catch(err){
                response.status(SERVER_ERROR).json({'message':'Error During OAuth '});
                console.log('OAuth Error', err);
            }
            //console.log('Req Body ', body);
            
        }
    }
