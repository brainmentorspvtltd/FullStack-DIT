const { compileAndRun } = require("../helper/program-executor");
const {SUCCESS} = require('../../../shared/config/constants').HTTP_STATUS_CODES;
// Request , Response Handling
module.exports = {
    compileAndRun(request, response){
        const body = request.body;
        console.log('Body is :::: ', body);
        const code = body.code;
        console.log('Code Rec ', code);
        const json = compileAndRun(code);
        response.status(SUCCESS).json(json);
    }
}