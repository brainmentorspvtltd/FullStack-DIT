const fs = require('fs');
const path = require('path');
const childProcess = require('child_process');
const programExecutor =  {
    compileAndRun(sourceCode){
        // Write the Source Code in a file.
        
        if(programExecutor.sourceCodeWrite(sourceCode)){
            let phase = '';
            console.log('Source code Write on Server.... ');
            const filePath   = path.join(process.env.SOURCE_LOCATION,'Solution.java');
            const fileName = path.basename(filePath);
            try{
                phase = 'Compilation Fails';
            let result= childProcess.execSync(`javac ${filePath}`);
            console.log('After Compile .... ', result.toString());
            //return {message:'Compilation SuccessFully '};
            // Execution
            phase = 'Execution Fails';
            result = childProcess.execSync(`cd ${process.env.SOURCE_LOCATION} 
             java ${fileName}  `);
             return {message:'Success',result : result.toString()};

            }
            catch(err){
                console.log('Error is ', err.stderr.toString(), 'Type of  ',typeof err);
                return {message:phase, details: err.stderr.toString()};
            }
        }
    }, 
    sourceCodeWrite(sourceCode){
        try{
        const filePath   = path.join(process.env.SOURCE_LOCATION,'Solution.java');
        fs.writeFileSync(filePath, sourceCode);
        return true;
        }
        catch(err){
            throw err;
        }
       
    }


}
module.exports = programExecutor;