const express = require('express');
const { compileAndRun } = require('../controllers/question-controller');
const routes = express.Router();
const {COMPILE_AND_RUN} =require('../../../shared/config/constants').ROUTES.QUESTION;
routes.post(COMPILE_AND_RUN, compileAndRun);
module.exports = routes;