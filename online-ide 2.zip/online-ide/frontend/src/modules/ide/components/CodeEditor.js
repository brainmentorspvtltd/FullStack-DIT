import React, { useRef } from 'react'
import Editor from '@monaco-editor/react';
import { API_CLIENT } from '../../../shared/services/api-client';
export const CodeEditor = ({output}) => {
  const editorRef = useRef({});
  const options = {
    'fontSize':30, selectOnLineNumbers:true, cursorStyle:'line',
    colorDecorators:true, scrollbar:{
      useShadows:false, verticalHasArrows : true, horizontalHasArrows: true, vertical : 'visible',
      horizontal: 'visible'
    }
  };

  const handleEditorDidMount = (editor, monaco)=>{
      editorRef.current = editor;
      console.log('handleEditorDidMount Call ');
  }

  const compileAndRun = async ()=>{
    console.log('Editor Ref ', editorRef.current);
      const code = editorRef.current.getValue();
      console.log('Code is ', code);
      const response = await API_CLIENT.post(process.env.REACT_APP_COMPILE_RUN, {code: code} );
      console.log(' COMPILE AND RUN Response ', response);
      if(response.data.details){
        output (response.data.message + " "+response.data.details);
      }
      else{
      output(response.data.message +" "+response.data.result);
      }
    }
  return (
    <div className='col'>
        <Editor theme='vs-dark' height="90%" 
        width="100%" defaultLanguage='java'
        onMount={handleEditorDidMount}
         defaultValue='class Solution {}'
         options={options}
         />
         <br/>
    <button className = 'btn btn-primary' onClick={compileAndRun}>Compile and Run</button>
    </div>
  )
}
