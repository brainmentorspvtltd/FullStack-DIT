import React from 'react'

export const OutputWindow = ({message}) => {
  return (
    <div className='col'>
        <p><strong>{message}</strong></p>
    </div>
  )
}
