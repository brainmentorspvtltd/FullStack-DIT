import React, { useState } from 'react'
import { CodeEditor } from '../components/CodeEditor'
import { OutputWindow } from '../components/OutputWindow'
import { Problem } from '../components/Problem'

export const ProblemStatement = () => {
  const [message, setMessage] = useState('');
  const getOutput = (msg)=>{
    setMessage(msg);
  }
  return (
    <div className='container'>
    <div className='row'>
        <Problem/>
       <CodeEditor output = {getOutput}/>
    </div>
    <div className='row'>
      Output is 
        <OutputWindow message={message}/>
       </div>
       </div>
  )
}
