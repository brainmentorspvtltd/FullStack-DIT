// Import the functions you need from the SDKs you need
import  { initializeApp } from "firebase/app";
import firebase from 'firebase/compat/app'; 
import { getAnalytics } from "firebase/analytics";

import { getAuth, GoogleAuthProvider, signInWithPopup } from "firebase/auth";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyBzSEglJ1UhNlM23PMj9sYTvAaYUHn1l5A",
  authDomain: "ide-auth.firebaseapp.com",
  projectId: "ide-auth",
  storageBucket: "ide-auth.appspot.com",
  messagingSenderId: "997431880144",
  appId: "1:997431880144:web:e34cd6499ac6c17021f1d5",
  measurementId: "G-BJ8VDH20XF"
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);

// Login with Gmail
export const loginWithGoogle = () => {
  const provider = new GoogleAuthProvider(); // Auth with GoogleAuthProvider
  console.log('Provider ', provider);
  const auth = getAuth();
  return signInWithPopup(auth, provider);
    }

const analytics = getAnalytics(app);