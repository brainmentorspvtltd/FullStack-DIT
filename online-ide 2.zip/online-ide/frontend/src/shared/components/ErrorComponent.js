import React from 'react'

export const ErrorComponent = () => {
  return (
    <div>
        <h1>OOPS Some Wrong URL ....</h1>
    </div>
  )
}
